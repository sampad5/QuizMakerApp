<?php
// get_quiz_questions.php
header('Content-Type: application/json');
require_once '../db.php';

$quizId = $_GET['quiz_id'] ?? null;

if (!$quizId) {
    echo json_encode(['success' => false, 'message' => 'Missing quiz ID']);
    exit;
}

$stmt = $conn->prepare("SELECT question_id, question_text, correct_option FROM questions WHERE quiz_id = ?");
$stmt->bind_param("i", $quizId);
$stmt->execute();
$questionsResult = $stmt->get_result();

$questions = [];
while ($q = $questionsResult->fetch_assoc()) {
    $questionId = $q['question_id'];
    $qText = $q['question_text'];

    $optStmt = $conn->prepare("SELECT option_label, option_text FROM options WHERE question_id = ? ORDER BY option_label ASC");
    $optStmt->bind_param("i", $questionId);
    $optStmt->execute();
    $optionsResult = $optStmt->get_result();

    $options = [];
    while ($opt = $optionsResult->fetch_assoc()) {
        $options[$opt['option_label']] = $opt['option_text'];
    }
    $optStmt->close();

    $questions[] = [
        'question_id' => $questionId,
        'question' => $qText,
        'options' => $options
    ];
}

$stmt->close();

echo json_encode(['success' => true, 'questions' => $questions]);
