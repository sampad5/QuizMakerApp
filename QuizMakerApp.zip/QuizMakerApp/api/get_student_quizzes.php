<?php
// get_student_quizzes.php
header('Content-Type: application/json');
require_once '../db.php';

$studentId = $_GET['student_id'] ?? null;

if (!$studentId) {
    echo json_encode(['success' => false, 'message' => 'Missing student ID']);
    exit;
}

// Get published and scheduled quizzes
$now = date('Y-m-d H:i:s');
$stmt = $conn->prepare("SELECT quiz_id, title, scheduled_time FROM quizzes 
                        WHERE is_published = 1 AND scheduled_time <= ?");
$stmt->bind_param("s", $now);
$stmt->execute();
$scheduled = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get past results
$stmt = $conn->prepare("SELECT q.title, r.score, r.rank FROM results r 
                        JOIN quizzes q ON r.quiz_id = q.quiz_id 
                        WHERE r.student_id = ?");
$stmt->bind_param("i", $studentId);
$stmt->execute();
$results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

echo json_encode([
    'success' => true,
    'scheduled' => $scheduled,
    'results' => $results
]);
