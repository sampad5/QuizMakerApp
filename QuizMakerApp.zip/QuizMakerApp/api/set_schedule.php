<?php
// set_schedule.php
header('Content-Type: application/json');
require_once '../db.php';

$data = json_decode(file_get_contents('php://input'), true);
$quizId = $data['quizId'] ?? null;
$scheduledTime = $data['scheduledTime'] ?? null;

if (!$quizId || !$scheduledTime) {
    echo json_encode(['success' => false, 'message' => 'Missing quiz ID or time']);
    exit;
}

$stmt = $conn->prepare("UPDATE quizzes SET scheduled_time = ? WHERE quiz_id = ?");
$stmt->bind_param("si", $scheduledTime, $quizId);
$stmt->execute();
$stmt->close();

echo json_encode(['success' => true, 'message' => 'Schedule set']);
