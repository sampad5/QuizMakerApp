<?php
require_once '../db.php';

header('Content-Type: application/json');

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$fileNames = $data['fileNames'];
$adminId = $data['adminId'];

try {
    // Start transaction
    $pdo->beginTransaction();
    
    // 1. Create quiz record
    $quizStmt = $pdo->prepare("INSERT INTO quizzes (admin_id, title, description) VALUES (?, ?, ?)");
    $quizTitle = "Quiz from " . implode(", ", $fileNames);
    $quizStmt->execute([$adminId, $quizTitle, "Automatically generated quiz"]);
    $quizId = $pdo->lastInsertId();
    
    // 2. Process files and generate questions (simplified example)
    foreach ($fileNames as $fileName) {
        // In a real app, you would parse the file and extract questions
        // This is a simplified example with mock questions
        
        // Example multiple choice question
        $qStmt = $pdo->prepare("INSERT INTO quiz_questions (quiz_id, question_text, question_type, points) VALUES (?, ?, ?, ?)");
        $qStmt->execute([$quizId, "What is the capital of France?", "multiple_choice", 1]);
        $questionId = $pdo->lastInsertId();
        
        // Add options
        $options = [
            ['Paris', true],
            ['London', false],
            ['Berlin', false],
            ['Madrid', false]
        ];
        
        $optStmt = $pdo->prepare("INSERT INTO question_options (question_id, option_text, is_correct) VALUES (?, ?, ?)");
        foreach ($options as $option) {
            $optStmt->execute([$questionId, $option[0], $option[1]]);
        }
    }
    
    $pdo->commit();
    echo json_encode(['success' => true, 'quizId' => $quizId]);
} catch (PDOException $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>