<?php
require_once '../db.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$username = sanitizeInput($data['username']);
$email = sanitizeInput($data['email']);
$password = sanitizeInput($data['password']);
$role = sanitizeInput($data['role']);
$adminCode = isset($data['adminCode']) ? sanitizeInput($data['adminCode']) : null;

// Validate admin code if registering as admin
if ($role === 'admin' && $adminCode !== 'ADMIN123') {
    echo json_encode(['success' => false, 'message' => 'Invalid admin access code']);
    exit;
}

try {
    // Check if username or email already exists
    $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
    $checkStmt->execute([$username, $email]);
    
    if ($checkStmt->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'message' => 'Username or email already exists']);
        exit;
    }
    
    // Hash password
    $passwordHash = password_hash($password, PASSWORD_BCRYPT);
    
    // Create user
    $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, ?)");
    $stmt->execute([$username, $email, $passwordHash, $role]);
    $userId = $pdo->lastInsertId();
    
    // Create role-specific record
    if ($role === 'admin') {
        $stmt = $pdo->prepare("INSERT INTO admin_details (admin_id, user_id, admin_code_used) VALUES (?, ?, ?)");
        $stmt->execute([$userId, $userId, $adminCode]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO student_profiles (student_id, user_id, full_name) VALUES (?, ?, ?)");
        $stmt->execute([$userId, $userId, $username]);
    }
    
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Registration failed: ' . $e->getMessage()]);
}
?>