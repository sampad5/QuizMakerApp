<?php
// get_rankings.php
header('Content-Type: application/json');
require_once '../db.php';

$quizId = $_GET['quiz_id'] ?? null;

if (!$quizId) {
    echo json_encode(['success' => false, 'message' => 'Missing quiz ID']);
    exit;
}

$stmt = $conn->prepare("SELECT u.username, r.score, r.rank
                        FROM results r
                        JOIN users u ON r.student_id = u.user_id
                        WHERE r.quiz_id = ?
                        ORDER BY r.rank ASC");
$stmt->bind_param("i", $quizId);
$stmt->execute();
$result = $stmt->get_result();

$ranking = [];
while ($row = $result->fetch_assoc()) {
    $ranking[] = $row;
}

echo json_encode(['success' => true, 'ranking' => $ranking]);
