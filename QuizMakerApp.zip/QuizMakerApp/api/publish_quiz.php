<?php
// publish_quiz.php
header('Content-Type: application/json');
require_once '../db.php';

$data = json_decode(file_get_contents('php://input'), true);
$quizId = $data['quizId'] ?? null;

if (!$quizId) {
    echo json_encode(['success' => false, 'message' => 'Quiz ID is required']);
    exit;
}

$stmt = $conn->prepare("UPDATE quizzes SET is_published = 1 WHERE quiz_id = ?");
$stmt->bind_param("i", $quizId);
$stmt->execute();
$stmt->close();

echo json_encode(['success' => true, 'message' => 'Quiz published successfully']);
