// script.js - Complete Version
document.addEventListener('DOMContentLoaded', function() {
    // Toggle between student and admin login
    const studentBtn = document.getElementById('student-btn');
    const adminBtn = document.getElementById('admin-btn');
    
    if (studentBtn && adminBtn) {
        studentBtn.addEventListener('click', function() {
            this.classList.add('active');
            adminBtn.classList.remove('active');
        });
        
        adminBtn.addEventListener('click', function() {
            this.classList.add('active');
            studentBtn.classList.remove('active');
        });
    }
    
    // Toggle between student and admin signup
    const signupStudentBtn = document.getElementById('signup-student-btn');
    const signupAdminBtn = document.getElementById('signup-admin-btn');
    const adminCodeGroup = document.getElementById('admin-code-group');
    
    if (signupStudentBtn && signupAdminBtn) {
        signupStudentBtn.addEventListener('click', function() {
            this.classList.add('active');
            signupAdminBtn.classList.remove('active');
            adminCodeGroup.style.display = 'none';
        });
        
        signupAdminBtn.addEventListener('click', function() {
            this.classList.add('active');
            signupStudentBtn.classList.remove('active');
            adminCodeGroup.style.display = 'block';
        });
    }
    
    // Toggle password visibility
    const togglePasswordIcons = document.querySelectorAll('.toggle-password');
    
    togglePasswordIcons.forEach(icon => {
        icon.addEventListener('click', function() {
            const input = this.previousElementSibling;
            const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
            input.setAttribute('type', type);
            this.classList.toggle('fa-eye-slash');
            this.classList.toggle('fa-eye');
        });
    });
    
    // Form validation for login
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const isStudent = studentBtn ? studentBtn.classList.contains('active') : true;
            
            // Basic validation
            if (!username || !password) {
                showError('Please fill in all fields');
                return;
            }
            
            try {
                const response = await fetch('api/login.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        username,
                        password,
                        role: isStudent ? 'student' : 'admin'
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    // Redirect based on role
                    window.location.href = isStudent ? 'student-dashboard.html' : 'admin.html';
                } else {
                    showError(data.message || 'Login failed. Please check your credentials.');
                }
            } catch (error) {
                console.error('Login error:', error);
                showError('An error occurred during login. Please try again.');
            }
        });
    }
    
    // Form validation for signup
    const signupForm = document.getElementById('signup-form');
    if (signupForm) {
        signupForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('signup-password').value;
            const isStudent = signupStudentBtn ? signupStudentBtn.classList.contains('active') : true;
            const adminCode = document.getElementById('admin-code').value;
            
            // Basic validation
            if (!username || !email || !password) {
                showError('Please fill in all required fields');
                return;
            }
            
            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                showError('Please enter a valid email address');
                return;
            }
            
            // Password strength validation
            if (password.length < 8) {
                showError('Password must be at least 8 characters long');
                return;
            }
            
            try {
                const response = await fetch('api/signup.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        username,
                        email,
                        password,
                        role: isStudent ? 'student' : 'admin',
                        adminCode: !isStudent ? adminCode : null
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert(`Successfully registered as ${isStudent ? 'student' : 'admin'}`);
                    window.location.href = 'index.html';
                } else {
                    showError(data.message || 'Registration failed. Please try again.');
                }
            } catch (error) {
                console.error('Signup error:', error);
                showError('An error occurred during registration. Please try again.');
            }
        });
    }
    
    // Admin dashboard functionality
    const dropArea = document.getElementById('dropArea');
    const fileInput = document.getElementById('fileInput');
    const browseBtn = document.getElementById('browseBtn');
    const fileList = document.getElementById('fileList');
    const generateBtn = document.getElementById('generateBtn');
    const chatMessages = document.getElementById('chatMessages');
    
    if (dropArea) {
        // Prevent default drag behaviors
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, preventDefaults, false);
            document.body.addEventListener(eventName, preventDefaults, false);
        });
        
        // Highlight drop area when item is dragged over it
        ['dragenter', 'dragover'].forEach(eventName => {
            dropArea.addEventListener(eventName, highlight, false);
        });
        
        ['dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, unhighlight, false);
        });
        
        // Handle dropped files
        dropArea.addEventListener('drop', handleDrop, false);
        
        // Handle file selection via browse button
        browseBtn.addEventListener('click', () => {
            fileInput.click();
        });
        
        fileInput.addEventListener('change', function() {
            handleFiles(this.files);
        });
        
        // Generate quiz button handler
        generateBtn.addEventListener('click', async function() {
            if (fileList.children.length === 0) {
                addAlertMessage('Please upload files before generating a quiz');
                return;
            }
            
            addSystemMessage('Generating quiz from uploaded files...');
            
            try {
                // Get all file names
                const files = Array.from(fileList.querySelectorAll('.file-name')).map(el => el.textContent);
                
                // Send to server for processing
                const response = await fetch('api/generate_quiz.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        fileNames: files,
                        adminId: getAdminId() // Get admin ID from session
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    addSystemMessage('Quiz generated successfully!');
                    // Redirect to quiz management
                    window.location.href = `quiz_edit.php?quiz_id=${data.quizId}`;
                } else {
                    addErrorMessage(data.message || 'Quiz generation failed');
                }
            } catch (error) {
                console.error('Quiz generation error:', error);
                addErrorMessage('An error occurred during quiz generation');
            }
        });
    }
    
    // Quiz edit page functionality
    const editQuestionButtons = document.querySelectorAll('.edit-question');
    const deleteQuestionButtons = document.querySelectorAll('.delete-question');
    const addQuestionBtn = document.getElementById('add-question-btn');
    const previewQuizBtn = document.getElementById('preview-quiz-btn');
    const publishQuizBtn = document.getElementById('publish-quiz-btn');
    
    if (editQuestionButtons) {
        editQuestionButtons.forEach(btn => {
            btn.addEventListener('click', function() {
                const questionId = this.dataset.id;
                editQuestion(questionId);
            });
        });
    }
    
    if (deleteQuestionButtons) {
        deleteQuestionButtons.forEach(btn => {
            btn.addEventListener('click', async function() {
                const questionId = this.dataset.id;
                if (confirm('Are you sure you want to delete this question?')) {
                    try {
                        const response = await fetch('api/delete_question.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({
                                questionId
                            })
                        });
                        
                        const data = await response.json();
                        
                        if (data.success) {
                            location.reload(); // Refresh to show changes
                        } else {
                            alert('Failed to delete question');
                        }
                    } catch (error) {
                        console.error('Delete question error:', error);
                        alert('An error occurred while deleting the question');
                    }
                }
            });
        });
    }
    
    if (addQuestionBtn) {
        addQuestionBtn.addEventListener('click', function() {
            // Get quiz ID from URL
            const quizId = new URLSearchParams(window.location.search).get('quiz_id');
            if (quizId) {
                window.location.href = `add_question.php?quiz_id=${quizId}`;
            }
        });
    }
    
    if (publishQuizBtn) {
        publishQuizBtn.addEventListener('click', async function() {
            const quizId = new URLSearchParams(window.location.search).get('quiz_id');
            if (!quizId) return;
            
            if (confirm('Publish this quiz? Students will be able to take it.')) {
                try {
                    const response = await fetch('api/publish_quiz.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            quizId
                        })
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        alert('Quiz published successfully!');
                        window.location.href = 'admin.html';
                    } else {
                        alert(data.message || 'Failed to publish quiz');
                    }
                } catch (error) {
                    console.error('Publish quiz error:', error);
                    alert('An error occurred while publishing the quiz');
                }
            }
        });
    }
    
    // Helper functions
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    function highlight() {
        dropArea.classList.add('active');
    }
    
    function unhighlight() {
        dropArea.classList.remove('active');
    }
    
    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        handleFiles(files);
    }
    
    function handleFiles(files) {
        if (files.length === 0) return;
        
        addSystemMessage(`Processing ${files.length} file(s)...`);
        
        // Clear previous files
        fileList.innerHTML = '';
        
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            displayFile(file);
        }
        
        addSystemMessage(`Successfully uploaded ${files.length} file(s)`);
    }
    
    function displayFile(file) {
        const fileItem = document.createElement('div');
        fileItem.className = 'file-item';
        
        const fileIcon = document.createElement('div');
        fileIcon.className = 'file-icon';
        
        // Set appropriate icon based on file type
        if (file.type.includes('pdf')) {
            fileIcon.innerHTML = '<i class="fas fa-file-pdf"></i>';
        } else if (file.type.includes('image')) {
            fileIcon.innerHTML = '<i class="fas fa-file-image"></i>';
        } else if (file.type.includes('word') || file.type.includes('document')) {
            fileIcon.innerHTML = '<i class="fas fa-file-word"></i>';
        } else if (file.type.includes('excel') || file.type.includes('spreadsheet')) {
            fileIcon.innerHTML = '<i class="fas fa-file-excel"></i>';
        } else if (file.type.includes('powerpoint') || file.type.includes('presentation')) {
            fileIcon.innerHTML = '<i class="fas fa-file-powerpoint"></i>';
        } else if (file.type.includes('video')) {
            fileIcon.innerHTML = '<i class="fas fa-file-video"></i>';
        } else if (file.type.includes('audio')) {
            fileIcon.innerHTML = '<i class="fas fa-file-audio"></i>';
        } else if (file.type.includes('zip') || file.type.includes('compressed')) {
            fileIcon.innerHTML = '<i class="fas fa-file-archive"></i>';
        } else {
            fileIcon.innerHTML = '<i class="fas fa-file"></i>';
        }
        
        const fileInfo = document.createElement('div');
        fileInfo.className = 'file-info';
        
        const fileName = document.createElement('div');
        fileName.className = 'file-name';
        fileName.textContent = file.name;
        
        const fileSize = document.createElement('div');
        fileSize.className = 'file-size';
        fileSize.textContent = formatFileSize(file.size);
        
        fileInfo.appendChild(fileName);
        fileInfo.appendChild(fileSize);
        
        const fileActions = document.createElement('div');
        fileActions.className = 'file-actions';
        
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'action-btn';
        deleteBtn.innerHTML = '<i class="fas fa-trash"></i>';
        deleteBtn.title = 'Remove file';
        deleteBtn.addEventListener('click', () => {
            fileItem.remove();
            addSystemMessage(`Removed file: ${file.name}`);
        });
        
        fileActions.appendChild(deleteBtn);
        fileItem.appendChild(fileIcon);
        fileItem.appendChild(fileInfo);
        fileItem.appendChild(fileActions);
        
        fileList.appendChild(fileItem);
    }
    
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    function addSystemMessage(text) {
        addMessage(text, 'system');
    }
    
    function addAlertMessage(text) {
        addMessage(text, 'alert');
    }
    
    function addErrorMessage(text) {
        addMessage(text, 'error');
    }
    
    function addMessage(text, type) {
        if (!chatMessages) return;
        
        const now = new Date();
        const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        
        const messageText = document.createElement('p');
        messageText.textContent = text;
        
        const messageTime = document.createElement('div');
        messageTime.className = 'message-time';
        messageTime.textContent = timeString;
        
        messageDiv.appendChild(messageText);
        messageDiv.appendChild(messageTime);
        
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    function showError(message) {
        const errorElement = document.getElementById('error-message') || createErrorElement();
        errorElement.textContent = message;
        errorElement.style.display = 'block';
        
        // Hide after 5 seconds
        setTimeout(() => {
            errorElement.style.display = 'none';
        }, 5000);
    }
    
    function createErrorElement() {
        const errorElement = document.createElement('div');
        errorElement.id = 'error-message';
        errorElement.className = 'error-message';
        errorElement.style.display = 'none';
        document.body.prepend(errorElement);
        return errorElement;
    }
    
    function getAdminId() {
        // In a real app, this would come from the session
        // For demo purposes, we'll return a mock ID
        return 1;
    }
    
    function editQuestion(questionId) {
        // Redirect to edit page
        window.location.href = `edit_question.php?question_id=${questionId}`;
    }
});