import sys
import fitz
import spacy
import json
from random import sample, shuffle

# Load spaCy English model
nlp = spacy.load("en_core_web_sm")

def extract_text(pdf_path):
    doc = fitz.open(pdf_path)
    return "\n".join(page.get_text() for page in doc)

def generate_mcqs(text):
    doc = nlp(text)
    entities = [ent.text for ent in doc.ents if len(ent.text.split()) == 1 and ent.label_ in ['PERSON', 'ORG', 'GPE', 'DATE']]
    entities = list(set(entities))
    questions = []

    used = set()
    for sent in doc.sents:
        for ent in sent.ents:
            if ent.text in entities and ent.text not in used:
                used.add(ent.text)
                question = sent.text.replace(ent.text, "_____")
                if question == sent.text:
                    continue

                correct = ent.text
                distractors = sample([e for e in entities if e != correct], k=3) if len(entities) > 3 else []
                if len(distractors) < 3:
                    continue

                options = distractors + [correct]
                shuffle(options)
                option_map = {chr(65 + i): val for i, val in enumerate(options)}
                correct_label = next(k for k, v in option_map.items() if v == correct)

                questions.append({
                    "question": question.strip(),
                    "options": option_map,
                    "correct": correct_label
                })

                if len(questions) >= 10:
                    break
        if len(questions) >= 10:
            break

    return questions

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python mcq_generator.py <pdf_path>")
        sys.exit(1)

    path = sys.argv[1]
    raw_text = extract_text(path)
    mcqs = generate_mcqs(raw_text)
    print(json.dumps(mcqs, indent=4))
