<?php
// db.php - database connection file

$servername = "localhost";
$username = "root";           // Default for XAMPP
$password = "";               // Default is empty in XAMPP
$dbname = "quizmaker";        // Use the name you created in phpMyAdmin

// Create a new connection object
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die(json_encode([
        'success' => false,
        'message' => 'Database connection failed: ' . $conn->connect_error
    ]));
}
?>
