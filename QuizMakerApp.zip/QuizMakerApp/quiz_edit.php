<?php
require_once 'db.php';

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.html');
    exit;
}

$quizId = $_GET['quiz_id'] ?? 0;

try {
    // Get quiz info
    $quizStmt = $pdo->prepare("SELECT * FROM quizzes WHERE quiz_id = ?");
    $quizStmt->execute([$quizId]);
    $quiz = $quizStmt->fetch(PDO::FETCH_ASSOC);
    
    // Get questions
    $questionsStmt = $pdo->prepare("SELECT * FROM quiz_questions WHERE quiz_id = ?");
    $questionsStmt->execute([$quizId]);
    $questions = $questionsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get options for each question
    foreach ($questions as &$question) {
        $optionsStmt = $pdo->prepare("SELECT * FROM question_options WHERE question_id = ?");
        $optionsStmt->execute([$question['question_id']]);
        $question['options'] = $optionsStmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Quiz - QuizMakerApp</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Include your sidebar from admin.html -->
        
        <div class="main-content">
            <div class="header">
                <div class="page-title">
                    <h2>Edit Quiz: <?= htmlspecialchars($quiz['title']) ?></h2>
                </div>
            </div>
            
            <div class="quiz-edit-section">
                <?php foreach ($questions as $question): ?>
                <div class="question-card">
                    <div class="question-header">
                        <h3>Question <?= $question['question_id'] ?></h3>
                        <div class="question-actions">
                            <button class="btn btn-outline edit-question" data-id="<?= $question['question_id'] ?>">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <button class="btn btn-outline delete-question" data-id="<?= $question['question_id'] ?>">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </div>
                    </div>
                    <div class="question-text"><?= htmlspecialchars($question['question_text']) ?></div>
                    
                    <?php if ($question['question_type'] === 'multiple_choice'): ?>
                    <div class="options-list">
                        <?php foreach ($question['options'] as $option): ?>
                        <div class="option-item <?= $option['is_correct'] ? 'correct-option' : '' ?>">
                            <span><?= htmlspecialchars($option['option_text']) ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
                
                <div class="add-question-section">
                    <button class="btn btn-primary" id="add-question-btn">
                        <i class="fas fa-plus"></i> Add New Question
                    </button>
                </div>
                
                <div class="quiz-actions">
                    <button class="btn btn-outline" id="preview-quiz-btn">
                        <i class="fas fa-eye"></i> Preview Quiz
                    </button>
                    <button class="btn btn-primary" id="publish-quiz-btn">
                        <i class="fas fa-check"></i> Publish Quiz
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>